export interface Vendavel {
    nome: string
    preco: number
}

export class Carro implements Vendavel {
    nome: string
    preco: number
}
